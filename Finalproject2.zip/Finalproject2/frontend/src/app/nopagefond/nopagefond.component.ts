import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nopagefond',
  templateUrl: './nopagefond.component.html',
  styleUrls: ['./nopagefond.component.css']
})
export class NopagefondComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
