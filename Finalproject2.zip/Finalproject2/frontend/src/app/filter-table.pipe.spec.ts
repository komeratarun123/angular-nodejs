import { FilterTablePipe } from './filter-table.pipe';

describe('FilterTablePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTablePipe();
    expect(pipe).toBeTruthy();
  });
});
